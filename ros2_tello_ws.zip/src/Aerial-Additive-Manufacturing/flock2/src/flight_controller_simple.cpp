#include "flight_controller_simple.hpp"

namespace drone_base
{
  FlightControllerSimple::FlightControllerSimple(rclcpp::Node &node,
                                                 rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr &cmd_vel_pub) :
    FlightControllerInterface(node, cmd_vel_pub)
  {
#undef CXT_MACRO_MEMBER
#define CXT_MACRO_MEMBER(n, t, d) CXT_MACRO_LOAD_PARAMETER(node_, (*this), n, t, d)
    CXT_MACRO_INIT_PARAMETERS(SIMPLE_CONTROLLER_ALL_PARAMS, validate_parameters)

#undef CXT_MACRO_MEMBER
#define CXT_MACRO_MEMBER(n, t, d) CXT_MACRO_PARAMETER_CHANGED(n, t)
    CXT_MACRO_REGISTER_PARAMETERS_CHANGED(node, (*this), SIMPLE_CONTROLLER_ALL_PARAMS, validate_parameters)

    _reset();
  }

  void FlightControllerSimple::validate_parameters()
  {
    stabilize_time_ = rclcpp::Duration::from_seconds(stabilize_time_sec_);
    x_controller_.set_coefficients(pid_x_kp_, pid_x_kd_);
    y_controller_.set_coefficients(pid_y_kp_, pid_y_kd_);
    z_controller_.set_coefficients(pid_z_kp_, pid_z_kd_);
    yaw_controller_.set_coefficients(pid_yaw_kp_, pid_yaw_kd_);

    RCLCPP_INFO(node_.get_logger(), "FlightControllerSimple Parameters");

#undef CXT_MACRO_MEMBER
#define CXT_MACRO_MEMBER(n, t, d) CXT_MACRO_LOG_PARAMETER(RCLCPP_INFO, node_.get_logger(), (*this), n, t, d)
    SIMPLE_CONTROLLER_ALL_PARAMS
  }

  void FlightControllerSimple::_reset()
  {
    last_odom_time_ = rclcpp::Time();
  }

  void FlightControllerSimple::_set_target(int target)
  {
    target_ = target;

    if (target_ < 0 || target_ >= plan_.poses.size()) {
      return;
    }

    curr_target_.fromMsg(plan_.poses[target_].pose);
    curr_target_time_ = rclcpp::Time(plan_.poses[target_].header.stamp);

    RCLCPP_INFO(node_.get_logger(), "target %d position: (%g, %g, %g), yaw %g, time %12lld",
                target_,
                curr_target_.x,
                curr_target_.y,
                curr_target_.z,
                curr_target_.yaw,
                RCL_NS_TO_MS(curr_target_time_.nanoseconds()));
  }

  bool FlightControllerSimple::_odom_callback(const nav_msgs::msg::Odometry::SharedPtr &msg)
  {
    bool retVal = false;

    rclcpp::Time msg_time(msg->header.stamp);
    DronePose pose;
    pose.fromMsg(msg->pose.pose);

    if (PoseUtil::is_valid_time(last_odom_time_) && msg_time > last_odom_time_) {

      if (msg_time > curr_target_time_) {
        DronePose test_pose{pose};
        test_pose.yaw = curr_target_.yaw;
        test_pose.z = curr_target_.z;

        if (curr_target_.close_enough(test_pose, close_enough_xyz_, close_enough_yaw_)) {
          set_target(target_ + 1);
        } else if (msg_time > curr_target_time_ + stabilize_time_) {
          retVal = true;
        }
      }

      if (!retVal) {
        auto dt = (msg_time - last_odom_time_).seconds();
        auto x_dot_actual = (pose.x - last_pose_.x) / dt;
        auto y_dot_actual = (pose.y - last_pose_.y) / dt;
        auto z_dot_actual = (pose.z - last_pose_.z) / dt;
        auto yaw_dot_actual = (pose.yaw - last_pose_.yaw) / dt;
        double ubar_x = x_controller_.calc(curr_target_.x, pose.x, 0., x_dot_actual);
        double ubar_y = y_controller_.calc(curr_target_.y, pose.y, 0., y_dot_actual);
        double ubar_z = z_controller_.calc(curr_target_.z, pose.z, 0., z_dot_actual);
        double ubar_yaw = yaw_controller_.calc(curr_target_.yaw, pose.yaw, 0., yaw_dot_actual);

        double throttle, strafe;
        PoseUtil::rotate_frame(ubar_x, ubar_y, pose.yaw, throttle, strafe);

        RCLCPP_INFO(node_.get_logger(), "%12lld "
                                        "x: targ %7.3f, curr %7.3f, throttle %7.3f "
                                        "y: targ %7.3f, curr %7.3f, strafe %7.3f",
                    RCL_NS_TO_MS(msg_time.nanoseconds()),
                    curr_target_.x, pose.x, throttle,
                    curr_target_.y, pose.y, strafe);

        publish_velocity(throttle, strafe, ubar_z, ubar_yaw);
      }
    }

    last_odom_time_ = msg_time;
    last_pose_ = pose;

    return retVal;
  }
}