import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction
from launch_ros.actions import Node

def generate_launch_description():
    # Launch the Gazebo simulation with fiducial markers
    gazebo_simulation = ExecuteProcess(
        cmd=['ros2', 'launch', 'tello_gazebo', 'vlam_launch.py'],
        output='screen'
    )

    # Send the takeoff command for each drone
    takeoff_drone1 = TimerAction(
        period=5.0,  # Wait for 5 seconds to ensure Gazebo is ready
        actions=[
            ExecuteProcess(
                cmd=[
                    'ros2', 'service', 'call', '/drone1/tello_action', 'tello_msgs/TelloAction', "{cmd: 'takeoff'}"
                ],
                output='screen'
            )
        ]
    )

    takeoff_drone2 = TimerAction(
        period=6.0,  # Staggered start to avoid collisions
        actions=[
            ExecuteProcess(
                cmd=[
                    'ros2', 'service', 'call', '/drone2/tello_action', 'tello_msgs/TelloAction', "{cmd: 'takeoff'}"
                ],
                output='screen'
            )
        ]
    )

    takeoff_drone3 = TimerAction(
        period=7.0,  # Staggered start to avoid collisions
        actions=[
            ExecuteProcess(
                cmd=[
                    'ros2', 'service', 'call', '/drone3/tello_action', 'tello_msgs/TelloAction', "{cmd: 'takeoff'}"
                ],
                output='screen'
            )
        ]
    )

    # Launch additional nodes
    visualization_node = Node(
        package='print_controller',
        executable='PrintVisualization3Drones',
        output='screen'
    )

    controller_node = Node(
        package='print_controller',
        executable='PrintController',
        output='screen'
    )

    payload_position_node = Node(
        package='print_controller',
        executable='PayloadPositionPublisher',
        output='screen'
    )

    return LaunchDescription([
        gazebo_simulation,
        takeoff_drone1,
        takeoff_drone2,
        takeoff_drone3,
        visualization_node,
        controller_node,
        payload_position_node
    ])
