import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction, DeclareLaunchArgument
from launch_ros.actions import Node

def generate_launch_description():
    
    #generate relative paths
    workspace_src_path = os.path.join(os.getenv('HOME'), 'ros2_tello_ws', 'src')
    map_path = os.path.join(workspace_src_path, 'Aerial-Additive-Manufacturing', 'print_controller', 'map', 'output_fiducial_map_3_drones_test.yaml')
    gcode_path = os.path.join(workspace_src_path, 'Aerial-Additive-Manufacturing', 'print_controller', 'gcodes', 'square.code')
    rviz_config_path = os.path.join(workspace_src_path, 'Aerial-Additive-Manufacturing', 'print_controller', 'config', 'drones3_sim.rviz')
    #Namespace for drones
    drones = ['drone1', 'drone2', 'drone3']
   
    # Parameters for drones
    drone_params = [
        {'drone_ip': '192.168.1.11', 'command_port': 11001, 'drone_port': 12001, 'data_port': 13001, 'video_port': 14001},
        {'drone_ip': '192.168.1.12', 'command_port': 11002, 'drone_port': 12002, 'data_port': 13002, 'video_port': 14002},
        {'drone_ip': '192.168.1.13', 'command_port': 11003, 'drone_port': 12003, 'data_port': 13003, 'video_port': 14003},
    ]

    #Tello Driver Nodes (1 per Drone)
    tello_drivers = [
        Node(package='tello_driver', executable='tello_driver_main', output='screen',
             name=f'driver{idx+1}', namespace=drones[idx], parameters=[drone_params[idx]])
        for idx in range(len(drones))
    ]
    #VMAP 1 for all Drones
    # vmap_main = Node(
    #     package='fiducial_vlam', 
    #     executable='vmap_main', 
    #     output='screen',
    #     name='vmap_main', 
    #     parameters=
    #     [{
    #         'publish_tfs': 1,
    #         'marker_length': 0.074999999999999997,
    #         'marker_map_load_full_filename': map_path,
    #         'make_not_use_map': 0
    #     }]
    # )
    # #VLOC Nodes (1 per Drone)
    # vloc_nodes = [
    #     Node(package='fiducial_vlam', executable='vloc_main', output='screen',
    #          name='vloc_main', namespace=namespace, parameters=[{
    #              'publish_tfs': 1,
    #              'base_frame_id': f'base_link_{idx+1}',
    #              't_camera_base_z': -0.035,
    #              'camera_frame_id': f'camera_link_{idx+1}',
    #              'publish_image_marked': 1}])
    #     for idx, namespace in enumerate(drones)
    # ]

    # Takeoff commands (zeitverzögert um 10 sec)
    takeoff_commands = [
        TimerAction(
            period=15.0,  # Staggered takeoff
            actions=[
                ExecuteProcess(
                    cmd=['ros2', 'service', 'call', f'/{drones[idx]}/tello_action', 'tello_msgs/TelloAction', "{cmd: 'takeoff'}"],
                    output='screen'
                )
            ]
        )
        for idx in range(len(drones))
    ]

        # Takeoff commands (zeitverzögert um 10 sec)
    land_commands = [
        TimerAction(
            period=45.0,  # Staggered takeoff
            actions=[
                ExecuteProcess(
                    cmd=['ros2', 'service', 'call', f'/{drones[idx]}/tello_action', 'tello_msgs/TelloAction', "{cmd: 'land'}"],
                    output='screen'
                )
            ]
        )
        for idx in range(len(drones))
    ]

    # # Launch additional nodes
    # visualization_node = Node(
    #     package='print_controller',
    #     executable='PrintVisualizationSingle',
    #     output='screen'
    # )

    # controller_node = Node(
    #     package='print_controller',
    #     executable='PrintControllerSelfPositioning',
    #     output='screen',
    #     arguments=['--ros-args', '--log-level', 'debug']
    # )

    # payload_position_node = Node(
    #     package='print_controller',
    #     executable='PayloadPositionPublisher',
    #     output='screen'
    # )




    # gcode_to_path = Node (
    #     package='gcode_to_path', 
    #     executable='PathFromGcode', 
    #     output='screen',
    #     parameters=[{'gcode_path': gcode_path}]
    # )





    return LaunchDescription([
    # Rviz
    #ExecuteProcess(cmd=['rviz2', '-d', rviz_config_path], output='screen'),
    # Marker map
    #vmap_main,
    # Tello Drivers
    *tello_drivers,
    # Controller and Visualization
    #visualization_node,
    #controller_node,
    #payload_position_node,
    # Vloc
    #*vloc_nodes,
    # Takeoff commands for drones   
    *takeoff_commands,
    #*land_commands
    ])

if __name__ == '__main__':
    generate_launch_description()