import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction
from launch_ros.actions import Node

def generate_launch_description():

    workspace_src_path = os.path.join(os.getenv('HOME'), 'ros2_tello_ws', 'src')
    rviz_config_path = os.path.join(workspace_src_path, 'Aerial-Additive-Manufacturing', 'print_controller', 'config', 'drones3_sim.rviz')
    # Launch the Gazebo simulation with fiducial markers
    gazebo_simulation = ExecuteProcess(
        cmd=['ros2', 'launch', 'tello_gazebo', 'vlam_launch.py'],
        output='screen'
    )

    # Send the takeoff command for each drone
    takeoff_drone1 = TimerAction(
        period=5.0,  # Wait for 5 seconds to ensure Gazebo is ready
        actions=[
            ExecuteProcess(
                cmd=[
                    'ros2', 'service', 'call', '/drone1/tello_action', 'tello_msgs/TelloAction', "{cmd: 'takeoff'}"
                ],
                output='screen'
            )
        ]
    )


    gcode = Node(
       package='gcode_to_path', 
       executable='PathFromGcode', 
       output='screen',
       parameters=[{'gcode_path': '/home/johannes/ros2_tello_ws/src/Aerial-Additive-Manufacturing/print_controller/gcodes/square.gcode'}]
       
    )

    # Launch additional nodes
    visualization_node = Node(
        package='print_controller',
        executable='PrintVisualizationSingle',
        output='screen'
    )

    controller_node = Node(
        package='print_controller',
        executable='PrintController',
        output='screen',
        #arguments=['--ros-args', '--log-level', 'debug']
    )



    return LaunchDescription([
        ExecuteProcess(cmd=['rviz2', '-d', rviz_config_path], output='screen'),
        gazebo_simulation,
        gcode,
        #takeoff_drone1,
        visualization_node,
        controller_node,
  
    ])
