import re
import numpy as np

# Regex für Pose- und Fehler-Zeilen
pose_regex = re.compile(
    r'\[PrintControllerSelfPositioning-7\] \[INFO\] \[(\d+\.\d+)\] \[path_follower_node\]: Aktuelle Pfadabweichung'
)
error_regex = re.compile(
    r'\[tello_driver_main-5\].*(error while decoding|concealing .+ errors)'
)

def analyze_log(file_path):
    with open(file_path, 'r') as f:
        lines = f.readlines()

    # Sammellisten und Variablen
    pose_timestamps = []
    error_durations = []

    # Flag und Variablen
    error_since_last_pose = False
    last_pose_time = None

    for line in lines:
        # Pose-Zeile?
        pose_match = pose_regex.search(line)
        if pose_match:
            current_pose_time = float(pose_match.group(1))
            pose_timestamps.append(current_pose_time)

            # Falls zwischen letzter Pose und dieser Pose ein Fehler auftrat ...
            if last_pose_time is not None and error_since_last_pose:
                # ... genau ein Fehlerblock
                duration = current_pose_time - last_pose_time
                error_durations.append(duration)

            # Reset des Flags für Fehler, da wir nun eine neue Pose-Zeile haben
            error_since_last_pose = False
            last_pose_time = current_pose_time

        else:
            # Keine Pose-Zeile -> Prüfen, ob eine echte Fehlerzeile
            if error_regex.search(line):
                # Wir haben mind. eine Fehlerzeile seit der letzten Pose
                error_since_last_pose = True

    # --- Statistische Auswertung ---
    if len(pose_timestamps) == 0:
        raise ValueError("Keine Pose-Daten gefunden (keine Drone Pose-Zeilen).")

    if len(pose_timestamps) == 1:
        raise ValueError("Nur ein Pose-Timestamp gefunden – Frequenz kann nicht berechnet werden.")

    # 1) Frequenz der Posen
    pose_intervals = np.diff(pose_timestamps)
    mean_interval = np.mean(pose_intervals)
    std_interval = np.std(pose_intervals)
    mean_frequency = 1.0 / mean_interval

    # 2) Gesamtlaufzeit (Zeit zwischen erster und letzter Pose)
    total_runtime = pose_timestamps[-1] - pose_timestamps[0]

    # 3) Fehlerblöcke
    error_block_count = len(error_durations)

    # 4) Dauerstatistik der Fehlerblöcke
    mean_error_duration = np.mean(error_durations) if error_durations else 0.0
    std_error_duration = np.std(error_durations) if error_durations else 0.0

    # 5) Fehler pro Minute
    if total_runtime > 0:
        errors_per_minute = error_block_count / (total_runtime / 60.0)
    else:
        errors_per_minute = 0.0

    return {
        "mean_pose_frequency": mean_frequency,
        "std_pose_interval": std_interval,
        "total_runtime": total_runtime,
        "error_block_count": error_block_count,
        "mean_error_duration": mean_error_duration,
        "std_error_duration": std_error_duration,
        "errors_per_minute": errors_per_minute
    }


def main():
    file_path = "/home/johannes/ros2_tello_ws/src/Aerial-Additive-Manufacturing/print_controller/CMD_Fenster_only_while_flight/107_Lux1300_3Drone_3drones_selfpositioning"

    results = analyze_log(file_path)

    print("\n--- Analyseergebnisse ---")
    print(f"Verwendete Datei: {file_path}")
    print(f"Mittlere Pose-Frequenz:      {results['mean_pose_frequency']:.3f} Hz")
    print(f"Std-Abw. Pose-Interval:      {results['std_pose_interval']:.4f} s")
    print(f"Gesamtlaufzeit:              {results['total_runtime']:.3f} s")

    print(f"Anzahl erkannter Fehlerblöcke: {results['error_block_count']}")
    if results['error_block_count'] > 0:
        print(f"Mittlere Fehlerblock-Dauer:    {results['mean_error_duration']:.3f} s")
        print(f"Std-Abw. Fehlerblock-Dauer:    {results['std_error_duration']:.3f} s")
        print(f"Fehler pro Minute:             {results['errors_per_minute']:.3f}")
    else:
        print("Keine Fehlerblöcke erkannt.")


if __name__ == "__main__":
    main()
