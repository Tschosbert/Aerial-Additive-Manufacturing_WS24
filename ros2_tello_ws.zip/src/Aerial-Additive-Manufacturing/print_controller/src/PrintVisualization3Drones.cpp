#include <cmath>
#include <vector>
#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "std_msgs/msg/bool.hpp"
#include "visualization_msgs/msg/marker.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "gcode_to_path/msg/print_path.hpp"
#include "gcode_to_path/msg/print_pose.hpp"
#include <fstream>

class PrintVisualizationNode : public rclcpp::Node {
public:
    PrintVisualizationNode()
        : Node("print_visualization_node") {
        extrudeSubscription_ = create_subscription<std_msgs::msg::Bool>(
            "/print/extrude", 10, std::bind(&PrintVisualizationNode::onExtrude, this, std::placeholders::_1));

        odomSubscriptionDrone1_ = create_subscription<nav_msgs::msg::Odometry>(
            "/drone1/camera_odom", 10, std::bind(&PrintVisualizationNode::onOdomDrone1, this, std::placeholders::_1));

        odomSubscriptionDrone2_ = create_subscription<nav_msgs::msg::Odometry>(
            "/drone2/camera_odom", 10, std::bind(&PrintVisualizationNode::onOdomDrone2, this, std::placeholders::_1));

        odomSubscriptionDrone3_ = create_subscription<nav_msgs::msg::Odometry>(
            "/drone3/camera_odom", 10, std::bind(&PrintVisualizationNode::onOdomDrone3, this, std::placeholders::_1));
        
        odomSubscriptionPayloadGT_ = create_subscription<nav_msgs::msg::Odometry>(
            "/payload/odom/groundtruth", 10, std::bind(&PrintVisualizationNode::onOdomPayloadGT, this, std::placeholders::_1));
        
        markerPublisher_ = create_publisher<visualization_msgs::msg::Marker>("/print/visualization", 0);
        
        odomSubscriptionPayload_ = create_subscription<nav_msgs::msg::Odometry>(
            "/payload/odom", 10, std::bind(&PrintVisualizationNode::onOdomPayload, this, std::placeholders::_1));       

        isExtruding_ = false;
        color_.a=1;
        color_.r=1;
        color_.g=0;
        color_.b=0;
        marker_.header.frame_id = "map";
        //marker_.lifetime = rclcpp::Duration::from_seconds(0);;
        marker_.action = visualization_msgs::msg::Marker::ADD;
        marker_.type = visualization_msgs::msg::Marker::SPHERE_LIST;
        marker_.scale.x = 0.001;
        marker_.scale.y = 0.001;
        marker_.scale.z = 0.001;
        marker_.color = color_;
        marker_points_.reserve(10000);
    }

private:
    void onExtrude(const std_msgs::msg::Bool::SharedPtr msg) {
        isExtruding_=msg->data;
        return;
    }

    void onOdomPayload(const nav_msgs::msg::Odometry::SharedPtr msg) {
        if(isExtruding_){
            // Extrahiere die Position aus der Nachricht
        const auto& position = msg->pose.pose.position;
        
        // Formatiere die Position als CSV-String
        std::ostringstream formatted_point;
        formatted_point << position.x << ", " << position.y << ", " << position.z;

        // Logge oder speichere die Daten (hier Ausgabe in der Konsole)
        RCLCPP_INFO(this->get_logger(), "Point: %s", formatted_point.str().c_str());
        
        // Optional: Falls eine Datei benötigt wird, kannst du hier schreiben
        std::ofstream outfile("Payload_points.csv", std::ios::app);
        outfile << formatted_point.str() << "\n";

        // Punkte weiterhin in marker_points_ hinzufügen und visualisieren
            marker_points_.push_back(msg->pose.pose.position);
            marker_.points = marker_points_;
            markerPublisher_->publish(marker_);  
        }
    }

    void onOdomPayloadGT(const nav_msgs::msg::Odometry::SharedPtr msg) {
        if(isExtruding_){
            // Extrahiere die Position aus der Nachricht
        const auto& position = msg->pose.pose.position;
        
        // Formatiere die Position als CSV-String
        std::ostringstream formatted_point;
        formatted_point << position.x << ", " << position.y << ", " << position.z;

        // Logge oder speichere die Daten (hier Ausgabe in der Konsole)
        RCLCPP_INFO(this->get_logger(), "Point: %s", formatted_point.str().c_str());
        
        // Optional: Falls eine Datei benötigt wird, kannst du hier schreiben
        std::ofstream outfile("Payload_GT_points.csv", std::ios::app);
        outfile << formatted_point.str() << "\n";
        }
    }

    void onOdomDrone1(const nav_msgs::msg::Odometry::SharedPtr msg) {
        if(isExtruding_){
            // Extrahiere die Position aus der Nachricht
        const auto& position = msg->pose.pose.position;
        
        // Formatiere die Position als CSV-String
        std::ostringstream formatted_point;
        formatted_point << position.x << ", " << position.y << ", " << position.z;

        // Logge oder speichere die Daten (hier Ausgabe in der Konsole)
        //RCLCPP_INFO(this->get_logger(), "Point: %s", formatted_point.str().c_str());
        
        // Optional: Falls eine Datei benötigt wird, kannst du hier schreiben
        std::ofstream outfile("Drone1_points.csv", std::ios::app);
        outfile << formatted_point.str() << "\n";

 
        }
    }

    void onOdomDrone2(const nav_msgs::msg::Odometry::SharedPtr msg) {
        if(isExtruding_){
            // Extrahiere die Position aus der Nachricht
        const auto& position = msg->pose.pose.position;
        
        // Formatiere die Position als CSV-String
        std::ostringstream formatted_point;
        formatted_point << position.x << ", " << position.y << ", " << position.z;

        // Logge oder speichere die Daten (hier Ausgabe in der Konsole)
        //RCLCPP_INFO(this->get_logger(), "Point: %s", formatted_point.str().c_str());
        
        // Optional: Falls eine Datei benötigt wird, kannst du hier schreiben
        std::ofstream outfile("Drone2_points.csv", std::ios::app);
        outfile << formatted_point.str() << "\n";


        }
    }
        void onOdomDrone3(const nav_msgs::msg::Odometry::SharedPtr msg) {
        if(isExtruding_){
            // Extrahiere die Position aus der Nachricht
        const auto& position = msg->pose.pose.position;
        
        // Formatiere die Position als CSV-String
        std::ostringstream formatted_point;
        formatted_point << position.x << ", " << position.y << ", " << position.z;

        // Logge oder speichere die Daten (hier Ausgabe in der Konsole)
        //RCLCPP_INFO(this->get_logger(), "Point: %s", formatted_point.str().c_str());
        
        // Optional: Falls eine Datei benötigt wird, kannst du hier schreiben
        std::ofstream outfile("Drone3_points.csv", std::ios::app);
        outfile << formatted_point.str() << "\n";


        }
    }

    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odomSubscriptionDrone1_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odomSubscriptionDrone2_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odomSubscriptionDrone3_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odomSubscriptionPayload_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odomSubscriptionPayloadGT_;
    rclcpp::Subscription<std_msgs::msg::Bool>::SharedPtr extrudeSubscription_;
    rclcpp::Publisher<visualization_msgs::msg::Marker>::SharedPtr markerPublisher_;
    
    gcode_to_path::msg::PrintPath printPath_;
    bool isExtruding_;
    std_msgs::msg::ColorRGBA color_;
    visualization_msgs::msg::Marker marker_;
    std::vector<geometry_msgs::msg::Point> marker_points_;
};

int main(int argc, char* argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<PrintVisualizationNode>());
    rclcpp::shutdown();
    return 0;
}
