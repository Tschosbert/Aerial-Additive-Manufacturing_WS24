#include <cmath>
#include <vector>
#include "tf2/LinearMath/Quaternion.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.hpp"
#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "std_msgs/msg/bool.hpp"
#include "visualization_msgs/msg/marker.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "gcode_to_path/msg/print_path.hpp"
#include "gcode_to_path/msg/print_pose.hpp"
/*#define PRINT_VELOCITY 0.35
#define NON_PRINT_VELOCITY 0.35
#define ACCURACY_DISTANCE 0.15
*/
#define PRINT_VELOCITY 0.02
#define NON_PRINT_VELOCITY 0.05
//#define ACCURACY_DISTANCE 0.015
#define ACCURACY_DISTANCE 0.015
#define ACCURACY_YAW 0.04
#define YAW_VELOCITY 0.4

#define K_FOLLOW 1.0
#define K_REPOSITION 0.3


#define DISTANCE_DRONES 1.0

enum class ControllerState {
    POSITIONING,
    FOLLOWING_PATH
};

class PathFollowerNode : public rclcpp::Node {
public:
    PathFollowerNode()
        : Node("path_follower_node"), currentState_(ControllerState::POSITIONING) {
        printPathSubscription_ = create_subscription<gcode_to_path::msg::PrintPath>(
            "/print/path", 10, std::bind(&PathFollowerNode::onPrintPath, this, std::placeholders::_1));

        odomSubscription1_ = create_subscription<nav_msgs::msg::Odometry>(
            "/drone1/base_odom", 10, std::bind(&PathFollowerNode::onOdom1, this, std::placeholders::_1));
        odomSubscription2_ = create_subscription<nav_msgs::msg::Odometry>(
            "/drone2/base_odom", 10, std::bind(&PathFollowerNode::onOdom2, this, std::placeholders::_1));
        odomSubscription3_ = create_subscription<nav_msgs::msg::Odometry>(
            "/drone3/base_odom", 10, std::bind(&PathFollowerNode::onOdom3, this, std::placeholders::_1));

        payloadOdomSubscription_ = create_subscription<nav_msgs::msg::Odometry>(
            "/payload/odom", 10, std::bind(&PathFollowerNode::onPayloadOdom, this, std::placeholders::_1));

        cmdVelPublisher1_ = create_publisher<geometry_msgs::msg::Twist>("/drone1/cmd_vel", 1);
        cmdVelPublisher2_ = create_publisher<geometry_msgs::msg::Twist>("/drone2/cmd_vel", 1);
        cmdVelPublisher3_ = create_publisher<geometry_msgs::msg::Twist>("/drone3/cmd_vel", 1);
        extrudePublisher_ = create_publisher<std_msgs::msg::Bool>("/print/extrude", 1);
        markerPublisher_ = create_publisher<visualization_msgs::msg::Marker>("/marker", 0);

        isExtruding_ = false;
        gotPath_ = false;
        currentPrintPoseIndex_ = 0;
        printPath_.path = {};

        color_.a = 1;
        color_.r = 1;
        color_.g = 0;
        color_.b = 0;
        marker_.header.frame_id = "map";
        // marker_.lifetime = rclcpp::Duration::from_seconds(0);;
        marker_.action = visualization_msgs::msg::Marker::ADD;
        marker_.type = visualization_msgs::msg::Marker::SPHERE_LIST;
        marker_.scale.x = 0.01;
        marker_.scale.y = 0.01;
        marker_.scale.z = 0.01;
        marker_.color = color_;
        marker_points_.reserve(10000);

        // Set target positions for positioning phase, ist ein gleichseitiges Dreieck, mit Seitenlänge 0,5
        targetPositions_ = {
            {0.0, 0.0, 0.5}, // Drone 1
            {0.0, (DISTANCE_DRONES), 0.5}, // Drone 2
            {-std::sqrt((DISTANCE_DRONES*DISTANCE_DRONES)-((DISTANCE_DRONES/2)*(DISTANCE_DRONES/2))), (DISTANCE_DRONES/2), 0.5} // Drone 3
        };

        distanceDroneToPayload_ = {
            {(DISTANCE_DRONES/2)*tan(0.5235987756), -(DISTANCE_DRONES/2), 0.0}, // Drone 1
            {(DISTANCE_DRONES/2)*tan(0.5235987756), +(DISTANCE_DRONES/2), 0.0}, // Drone 2
            {-(std::sqrt((DISTANCE_DRONES*DISTANCE_DRONES)-((DISTANCE_DRONES/2)*(DISTANCE_DRONES/2)))-(DISTANCE_DRONES/2)*tan(0.5235987756)), 0.0, 0.0} // Drone 3
        };
        //RCLCPP_DEBUG(get_logger(), "Targetposition Drone 3 in X: %f, Y: %f, Z: %f", i, targetPositions_[2][0], targetPositions_[2][1], targetPositions_[2][2]);
            
    }

private:
    void onPrintPath(const gcode_to_path::msg::PrintPath::SharedPtr msg) {
        if (!gotPath_) {
            if (msg->path.empty()) {
                RCLCPP_WARN(get_logger(), "Received an empty PrintPath message.");
                return;
            } else {
                printPath_ = *msg;
                currentPrintPoseIndex_ = 0;
                gotPath_ = true;
                RCLCPP_INFO(get_logger(), "Stored the print path with %ld poses", printPath_.path.size());
            }
        }
    }

    void onOdom1(const nav_msgs::msg::Odometry::SharedPtr msg) {
        odomData_[0] = *msg;
        processOdometry();
    }

    void onOdom2(const nav_msgs::msg::Odometry::SharedPtr msg) {
        odomData_[1] = *msg;
        processOdometry();
    }

    void onOdom3(const nav_msgs::msg::Odometry::SharedPtr msg) {
        odomData_[2] = *msg;
        processOdometry();
    }

    void onPayloadOdom(const nav_msgs::msg::Odometry::SharedPtr msg) {
        payloadOdom_ = *msg;
            if (isExtruding_) {
                marker_points_.push_back(msg->pose.pose.position);
                marker_.points = marker_points_;
                markerPublisher_->publish(marker_);
                //RCLCPP_INFO(get_logger(), "Published marker at position - x: %f, y: %f, z: %f", msg->pose.pose.position.x, msg->pose.pose.position.y, msg->pose.pose.position.z);
            }
    }

    void processOdometry() {
        switch (currentState_) {
        case ControllerState::POSITIONING:
            handlePositioning();
            break;
        case ControllerState::FOLLOWING_PATH:
            handlePathFollowing();
            break;
        }
    }

    double getYawFromQuaternion(const geometry_msgs::msg::Quaternion& quat) {
        tf2::Quaternion tf2_quat(quat.x, quat.y, quat.z, quat.w);
        tf2::Matrix3x3 mat(tf2_quat);
        double roll, pitch, yaw;
        mat.getRPY(roll, pitch, yaw);
        return yaw;
    }

    void handlePositioning() {
        bool drone1Positioned = false;
        bool drone2Positioned = false;
        bool drone3Positioned = false;

        for (size_t i = 0; i < targetPositions_.size(); ++i) {
            
            geometry_msgs::msg::Twist twistMsg;
            double dx = targetPositions_[i][0] - odomData_[i].pose.pose.position.x;
            double dy = targetPositions_[i][1] - odomData_[i].pose.pose.position.y;
            double dz = targetPositions_[i][2] - odomData_[i].pose.pose.position.z;
            double yaw = getYawFromQuaternion(odomData_[i].pose.pose.orientation);
            double distance = std::sqrt(dx * dx + dy * dy + dz * dz);
            
            //Werte anzeigne lassen im Debug
            RCLCPP_DEBUG(get_logger(), "Aktueller Yaw-Wert: %f", yaw);
            RCLCPP_DEBUG(get_logger(), "Aktuelle Position Drone %zu in X: %f, Y: %f, Z: %f", i+1, odomData_[i].pose.pose.position.x, odomData_[i].pose.pose.position.y, odomData_[i].pose.pose.position.z);
            

            if (distance > ACCURACY_DISTANCE || std::fabs(yaw) > ACCURACY_YAW)
                {
                    twistMsg.linear.x = (dx * cos(yaw) + dy * sin(yaw)) * NON_PRINT_VELOCITY;
                    twistMsg.linear.y = (-dx * sin(yaw) + dy * cos(yaw)) * NON_PRINT_VELOCITY;
                    twistMsg.linear.z = dz * NON_PRINT_VELOCITY;
                    twistMsg.angular.z = -yaw * YAW_VELOCITY;

                    if (i == 0)
                    {
                        cmdVelPublisher1_->publish(twistMsg);
                    }
                    else if (i == 1)
                    {
                        cmdVelPublisher2_->publish(twistMsg);
                    }
                    else if (i == 2)
                    {
                        cmdVelPublisher3_->publish(twistMsg);
                    }
                }
                else
                {
                    if (i == 0)
                    {
                        drone1Positioned = true;
                        twistMsg.linear.x = 0;
                        twistMsg.linear.y = 0;
                        twistMsg.linear.z = 0;
                        twistMsg.angular.z = 0;
                        cmdVelPublisher1_->publish(twistMsg);
                    }
                    else if (i == 1)
                    {
                        drone2Positioned = true;
                        twistMsg.linear.x = 0;
                        twistMsg.linear.y = 0;
                        twistMsg.linear.z = 0;
                        twistMsg.angular.z = 0;
                        cmdVelPublisher2_->publish(twistMsg);
                    }
                    else if (i == 2)
                    {
                        drone3Positioned = true;
                        twistMsg.linear.x = 0;
                        twistMsg.linear.y = 0;
                        twistMsg.linear.z = 0;
                        twistMsg.angular.z = 0;
                        cmdVelPublisher3_->publish(twistMsg);
                    }
                }

            


        }

        if (drone1Positioned && drone2Positioned && drone3Positioned) {
            currentState_ = ControllerState::FOLLOWING_PATH;
        }
    }


    void handlePathFollowing() {
    if (currentPrintPoseIndex_ >= printPath_.path.size()) {
        gotPath_ = false;
        return;
    }

    gcode_to_path::msg::PrintPose printPose = printPath_.path[currentPrintPoseIndex_];
    isExtruding_ = printPose.print;

    // Error for path following
    double error_path_x = printPose.pose.pose.position.x - payloadOdom_.pose.pose.position.x;
    double error_path_y = printPose.pose.pose.position.y - payloadOdom_.pose.pose.position.y;
    double error_path_z = printPose.pose.pose.position.z - payloadOdom_.pose.pose.position.z;
    
    //Debugg nachrichten
    RCLCPP_DEBUG(get_logger(), "Aktuelle Pfadabweichung X: %f, Y: %f, Z: %f", error_path_x, error_path_y, error_path_z);



    // Calculate distance to the next pose
    double distance_to_goal = std::sqrt(error_path_x * error_path_x +
                                        error_path_y * error_path_y +
                                        error_path_z * error_path_z);

    if (distance_to_goal < ACCURACY_DISTANCE) {
        RCLCPP_INFO(get_logger(), "Reached PrintPose index: %ld", currentPrintPoseIndex_);
        currentPrintPoseIndex_++;
    } else {
for (size_t i = 0; i < 3; ++i) {
    // Fehler für die Formation basierend auf Payload-Position
            
            double error_position_x;
            double error_position_y;
            double error_position_z;
            double yaw;
            if(i!=0)
            {
             error_position_x = odomData_[i].pose.pose.position.x - odomData_[0].pose.pose.position.x - targetPositions_[i][0] ;
             error_position_y = odomData_[i].pose.pose.position.y - odomData_[0].pose.pose.position.y - targetPositions_[i][1];
             error_position_z = odomData_[i].pose.pose.position.z - odomData_[0].pose.pose.position.z;
             yaw = getYawFromQuaternion(odomData_[i].pose.pose.orientation);
            }

            // Debug-Nachrichten
            RCLCPP_DEBUG(get_logger(), "Aktuelle Positionsabweichung Drone %zu in X: %f, Y: %f, Z: %f", i, error_position_x, error_position_y, error_position_z);

            // Combine path following and repositioning errors
            double vel_x = ((K_FOLLOW * error_path_x) - (K_REPOSITION * error_position_x)) * PRINT_VELOCITY;
            double vel_y = ((K_FOLLOW * error_path_y) - (K_REPOSITION * error_position_y)) * PRINT_VELOCITY;
            double vel_z = ((K_FOLLOW * error_path_z) - (K_REPOSITION * error_position_z)) * PRINT_VELOCITY;

            // Publish velocities to the corresponding drone
            geometry_msgs::msg::Twist twistMsg;
            twistMsg.linear.x = vel_x * cos(yaw) + vel_y * sin(yaw);
            twistMsg.linear.y = -vel_x * sin(yaw) + vel_y * cos(yaw);
            twistMsg.linear.z = vel_z;
            twistMsg.angular.z = -yaw * YAW_VELOCITY;


            if (i == 0) {
                cmdVelPublisher1_->publish(twistMsg);
            } else if (i == 1) {
                cmdVelPublisher2_->publish(twistMsg);
            } else if (i == 2) {
                cmdVelPublisher3_->publish(twistMsg);
            }
        }


        // Publish the extrusion state
        std_msgs::msg::Bool extrudeMsg;
        extrudeMsg.data = printPose.print;
        extrudePublisher_->publish(extrudeMsg);

            if (isExtruding_) {
                marker_points_.push_back(payloadOdom_.pose.pose.position);
                marker_.points = marker_points_;
                markerPublisher_->publish(marker_);
                //RCLCPP_INFO(get_logger(), "Published marker at position - x: %f, y: %f, z: %f", msg->pose.pose.position.x, msg->pose.pose.position.y, msg->pose.pose.position.z);
            }
        }
        
    }


    rclcpp::Subscription<gcode_to_path::msg::PrintPath>::SharedPtr printPathSubscription_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odomSubscription1_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odomSubscription2_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odomSubscription3_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr payloadOdomSubscription_;

    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmdVelPublisher1_;
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmdVelPublisher2_;
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmdVelPublisher3_;
    rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr extrudePublisher_;
    rclcpp::Publisher<visualization_msgs::msg::Marker>::SharedPtr markerPublisher_;

    gcode_to_path::msg::PrintPath printPath_;
    bool gotPath_;
    bool isExtruding_;
    size_t currentPrintPoseIndex_;
    std_msgs::msg::ColorRGBA color_;
    visualization_msgs::msg::Marker marker_;
    std::vector<geometry_msgs::msg::Point> marker_points_;

    std::vector<std::array<double, 3>> targetPositions_;
    std::vector<std::array<double, 3>> distanceDroneToPayload_;
    ControllerState currentState_;

    
    std::array<nav_msgs::msg::Odometry, 3> odomData_;
    nav_msgs::msg::Odometry payloadOdom_;
};

int main(int argc, char* argv[]) {
    rclcpp::init(argc, argv);
    RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Starting PathFollowerNode...");
    rclcpp::spin(std::make_shared<PathFollowerNode>());
    rclcpp::shutdown();
    return 0;
}
